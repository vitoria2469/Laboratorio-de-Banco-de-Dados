package com.fatec.agis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoAgisApplicationTests {

	@Test
	void contextLoads() {
	}

}
