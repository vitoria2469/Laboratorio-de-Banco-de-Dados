package com.fatec.agis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoAgisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoAgisApplication.class, args);
	}

}
